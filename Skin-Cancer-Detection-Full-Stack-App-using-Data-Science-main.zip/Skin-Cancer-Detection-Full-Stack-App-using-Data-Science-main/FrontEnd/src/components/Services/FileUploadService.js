import http from "../ImageUploads/http-common";

const upload = (file, onUploadProgress) => {
  let formData = new FormData();

  formData.append("file", file);

  return http.post("/api/model", formData, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
    onUploadProgress,
  });
};

// const getFiles = () => {
//   return http.get("/files");
// };

const FileUploadService = {
  upload,
  // getFiles,
};

export default FileUploadService;
