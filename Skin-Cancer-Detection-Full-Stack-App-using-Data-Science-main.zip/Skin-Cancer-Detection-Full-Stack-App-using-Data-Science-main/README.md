# Olympians

Full stack web app to detet skin cancer/detection using data science

Front end is done using react js 
back end is done using Python and connected through Flask API
model is trained using Google Colab 
Datasets were collected from Kaggle

A pre trained model was used called Resnet Model for this.


